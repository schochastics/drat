# networkdata 0.1.2

* some movie data was wrongly mapped. should be fixed now.

# networkdata 0.1.1

* `show_networks()` was returning a tibble which requires additional dependencies. The function now returns a data.frame

# networkdata 0.1.0

* Added a `NEWS.md` file to track changes to the package.

#networkdata 0.1.6

fixed error in `southern_women`

# networkdata 0.1.5

* added starwars networks
* removed `show_networks()`

# networkdata 0.1.4

* fixed list issue in `animal_34`
* fixed genders in `crime` (#5)

# networkdata 0.1.3

* fixed name mapping in florentine families dataset.

# networkdata 0.1.2

* some movie data was wrongly mapped. should be fixed now.

# networkdata 0.1.1

* `show_networks()` was returning a tibble which requires additional dependencies. The function now returns a data.frame

# networkdata 0.1.0

* Added a `NEWS.md` file to track changes to the package.
